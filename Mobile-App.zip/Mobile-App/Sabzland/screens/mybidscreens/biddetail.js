import React from 'react';
import {View, Text, StyleSheet, Image, Button} from 'react-native';

const BidDetails = ({navigation}) => {
    return(
        <View style={styles.container}>
          <Text>Spash</Text>
          <Button
          title="Go to Details"
          onPress={() => navigation.navigate('intro')}
          />
        </View>
        
    )
}

export default BidDetails

const styles= StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FAFAFA',
        alignItems: 'center',
        justifyContent: 'center',
      },
      stretch: {
        width: 300,
        height: 300,
      },
})