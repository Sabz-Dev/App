import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import AllBids from '../mybidscreens/allbids'
import RelevantBids from '../mybidscreens/relevantbids'

const Tab = createMaterialTopTabNavigator();

function Cart() {
  return (
    <Tab.Navigator
    screenOptions={{
      tabBarActiveTintColor: '#5CDB95',
      tabBarInactiveTintColor: '#5D5C61',
      tabBarPressColor:'#f0f9f6',
      tabBarPressOpacity: 1,
      tabBarIndicatorStyle:{
        backgroundColor: '#5CDB95',
        height: 2,
      },
    }}
    >  
      <Tab.Screen name="All Bids" component={AllBids} />
      <Tab.Screen name="Relevant Bids" component={RelevantBids} />
    </Tab.Navigator>
  );
}
export default Cart