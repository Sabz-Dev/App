import React, {useRef, useState} from 'react'
import {View, Text, StyleSheet, Image, Button, FlatList, Dimensions, TouchableOpacity} from 'react-native'
import Icon from 'react-native-vector-icons/Feather';

const RelevantBids = ({navigation}) => {

    const bids = [
      {
        id: '1',
        date: 'July 17, 2022',
        name: 'Fruits',
        quality: 'Export',
        iconName: 'home',
      },
      {
        id: '2',
        date: 'July 17, 2022',
        name: 'Vegetables',
        quality: 'Export',
        iconName: 'activity',
      },
      {
        id: '3',
        date: 'July 17, 2022',
        name: 'Grains',
        quality: 'Export',
        iconName: 'box',
      },
      {
        id: '4',
        date: 'July 17, 2022',
        name: 'Tin Food',
        quality: 'Export',
        iconName: 'user',
        
      },
      {
        id: '5',
        date: 'July 17, 2022',
        name: 'Natural Juice',
        quality: 'Export',
        iconName: 'user',
        
      },
      {
        id: '6',
        date: 'July 17, 2022',
        name: 'Tin Food',
        quality: 'Export',
        iconName: 'user',
        
      },
    ];
    

    return(
        <View style={styles.container}>

          {/* <Text style = {styles.text}>Categories</Text> */}
        
        <FlatList 
          // numColumns={2}
          data = {bids}
          renderItem = {({item}) => 
          <TouchableOpacity style={styles.allbids}>
            {/* <View style = {{backgroundColor: 'white', borderWidth: 1, borderColor: '#626262', height: 50, width: 50}}/> */}
            <Icon name='activity' color={'#5CDB95'} size={25} />
          <View>
            <View style = {{ alignItems: 'center', justifyContent: 'center' }}>
              <Text style = {{ fontWeight: 'bold', fontSize: 25, color: '#5D5C61', paddingTop: 15, alignItems: 'center', justifyContent: 'center' }}>{item.name}</Text>
            </View>
            <View style={styles.profilecontent}>
              <Text style = {{ fontSize: 15, color: '#5D5C61',  paddingTop: 15 }}>{item.date}</Text>
              <Text style = {{ fontWeight: 'bold', fontSize: 15, color: '#5D5C61', paddingLeft: 75, paddingTop: 15 }}>Quality:</Text>
              <Text style = {{ fontSize: 15, color: '#5D5C61', paddingLeft: 5, paddingTop: 15 }}>{item.quality}</Text>
          </View>
          </View>

            {/* <Text>{item.price}</Text> */}
          </TouchableOpacity>
        }
        />
      </View> 
    )
}

export default RelevantBids

const styles= StyleSheet.create({
    container: {
        flex: 1,
        marginLeft: 5,
        marginRight: 5,
        backgroundColor: '#FAFAFA',
      },

      text:{
        //position: 'absolute', right: 0, bottom: 0,
        //marginTop: 50,
        paddingTop: 15,
        paddingLeft: 20,
        paddingBottom: 5,
        color:'#5D5C61',
        fontSize: 25,
        fontWeight: 'bold',
        },
        allbids: {
          backgroundColor: '#f0f9f6',
          padding: 10,
          marginVertical: 8,
          marginHorizontal: 16,
          borderRadius: 8,
          shadowColor: '#000',
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 3,
          },
          shadowOpacity: 0.29,
          shadowRadius: 4.65,
          elevation: 7,
          display: 'flex',
          flexDirection: 'row',
        },
        profilecontent: {
          //paddingRight: 10,
          display: 'flex',
          flexDirection: 'row',
        },
        profileicon: {
          paddingTop: 15,
          paddingLeft: 10,
          paddingBottom: 15,
        },
})