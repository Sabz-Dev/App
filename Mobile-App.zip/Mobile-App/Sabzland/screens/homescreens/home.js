import React, {useRef, useState} from 'react'
import {View, Text, StyleSheet, Image, Button, FlatList, Dimensions, TouchableOpacity} from 'react-native'
import Icon from 'react-native-vector-icons/Feather';

const {width, height} = Dimensions.get('window');
const carousalItems = [
  {imgUrl: require('./../../assets//Sabzland-green.png')},
    {imgUrl: require('./../../assets//Sabzland-green.png')},
    {imgUrl: require('./../../assets//Sabzland-green.png')},
]
const viewConfigRef = {ViewAreaCoveragePercentThreshold: 95}


const CarousalItem = ({text, imgUrl,  navigation}) => {
    return(
        <View style={styles.carousalContainer}>
            <Image style={styles.carousalImage} source={imgUrl}/>
        </View>
    )
}

const renderCarousalItem = ({item}) => {
    return(
        <CarousalItem text={item.text} imgUrl={item.imgUrl}/>
    )
}

const scrollToIndex = (index) => {
    flatlistRef.current?.scrollToIndex({animated: true, index: index})
}


const Homescreen = ({navigation}) => {
    let flatlistRef = useRef()
    const [currentIndex, setCurrentIndex] = useState(0)
    const onViewRef = useRef(({changed}) => {
        if (changed[0].isViewable) {
            setCurrentIndex(changed[0].index)
        }
    })

    const countries = [
      {
        id: '1',
        name: 'Fruits',
        iconName: 'home',
      },
      {
        id: '2',
        name: 'Vegetables',
        iconName: 'activity',
      },
      {
        id: '3',
        name: 'Grains',
        iconName: 'box',
      },
      {
        id: '4',
        name: 'Tin Food',
        iconName: 'user',
        
      },
    ];
    

    return(
        <View style={styles.container}>
          <View style={styles.carousalpart}>
            <FlatList 
                data={carousalItems}
                renderItem={renderCarousalItem}
                keyExtractor={(item, index) => index.toString()}
                style={styles.flatlistStyle}
                horizontal
                showsHorizontalScrollIndicator={false}
                pagingEnabled
                ref={(ref) => {flatlistRef.current = ref}} 
                onViewableItemsChanged={onViewRef.current}
            />
          </View>
          <Text style = {styles.text}>Categories</Text>
        
        <FlatList 
          numColumns={2}
          data = {countries}
          renderItem = {({item}) => 
          <TouchableOpacity style={styles.item}>
            {/* <View style = {{backgroundColor: 'white', borderWidth: 1, borderColor: '#626262', height: 50, width: 50}}/> */}
            <Icon name={item.iconName} color={'#5CDB95'} size={50} />
            <View style={styles.textitem}>
              <Text style = {{ fontSize: 15, color: '#5D5C61', marginTop: 5}}>{item.name}</Text>
            </View>
            {/* <Text>{item.price}</Text> */}
          </TouchableOpacity>
        }
        />
        <TouchableOpacity style={styles.currentbids}>
          {/* <View style = {{backgroundColor: 'white', borderWidth: 1, borderColor: '#626262', height: 50, width: 50}}/> */}
          <View style={styles.profileicon}>
            {/* <Icon name='activity' color={'#4D6D9A'} size={40} /> */}
            <Icon name='activity' color={'#5CDB95'} size={40} />
          </View>
          <View style={styles.profilecontent}>
            <Text style = {{ fontWeight: 'bold', fontSize: 18, color: '#5D5C61', paddingLeft: 25, paddingTop: 5 }}>Current Biding Status</Text>
            <Text style = {{ fontSize: 15, color: '#5D5C61', paddingLeft: 25, paddingTop: 5 }}>Check your biding status to avail maximum chances.</Text>
          </View>
          
          
          {/* <Text>{item.price}</Text> */}
        </TouchableOpacity>
      </View> 
    )
}

export default Homescreen

const styles= StyleSheet.create({
    container: {
        flex: 1,
        marginLeft: 5,
        marginRight: 5,
        backgroundColor: '#FAFAFA',
        //alignItems: 'center',
        //justifyContent: 'center',
      },
      // stretch: {
      //   width: 200,
      //   height: 200,
      // },
      carousalContainer:{
        alignItems:'center',
      },
      carousalImage: {
        width: 350,
        height: 150,
        resizeMode: 'cover',
        //marginLeft: 25,
        //marginRight: 25,
        //backgroundColor: '#5CDB95',
        backgroundColor: '#f0f9f6',
        borderRadius: 25,        
      },
      flatlistStyle:{
        
      },
      textitem: {
        backgroundColor: '#FAFAFA',
        width: 148,
        height: 30,
        position: 'absolute', right: 0, bottom: 0,
        alignItems: 'center',
        jutifyContent: 'center',
        // borderColor: 'black',
        borderColor:'grey',borderTopWidth:0.1,
        //borderWidth: 5,
        borderBottomLeftRadius: 10,
        borderBottomRightRadius: 10,
        
      },

      text:{
        //position: 'absolute', right: 0, bottom: 0,
        //marginTop: 50,
        paddingTop: 15,
        paddingLeft: 20,
        paddingBottom: 5,
        color:'#5D5C61',
        fontSize: 25,
        fontWeight: 'bold',
        },
        item: {
          backgroundColor: '#f0f9f6',
          alignItems: 'center',
          jutifyContent: 'center',
          paddingTop: 10,
          marginVertical: 14,
          marginHorizontal: 12,
          borderRadius: 10,
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 3,
          },
          shadowOpacity: 0.29,
          shadowRadius: 4.65,
          elevation: 7,
          width: 150,
          height: 100,
          borderColor: '#5D5C61',
          borderWidth: 0.5,
        },
        currentbids: {
          backgroundColor: '#f0f9f6',
          padding: 10,
          marginVertical: 8,
          marginHorizontal: 16,
          borderRadius: 8,
          shadowColor: '#000',
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 3,
          },
          shadowOpacity: 0.29,
          shadowRadius: 4.65,
          elevation: 7,
          display: 'flex',
          flexDirection: 'row',
        },
        profilecontent: {
          paddingRight: 10,
        },
        profileicon: {
          paddingTop: 15,
          paddingLeft: 10,
          paddingBottom: 15,
        },
})