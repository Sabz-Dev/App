import React, {useRef, useState} from 'react'
import {View, Text, StyleSheet, Image, Button, FlatList, Dimensions, TouchableOpacity} from 'react-native'
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

import Home from '../homescreens/home'
import Mybid from '../mybidscreens/bids'
import Cart from '../cart'
import MyProfile from '../profilescreens/myprofile'
//import LottieView from "lottie-react-native";
import Icon from 'react-native-vector-icons/Feather';

const Tabs = createBottomTabNavigator();

const Tab = ({navigation}) => {

    return (

        <Tabs.Navigator

            screenOptions={({ route }) => ({
                tabBarShowLabel: true,
                tabBarHideOnKeyboard: true,
                tabBarIcon: ({ focused, color, size }) => {
                    let iconName;

                    switch (route.name) {
                        case 'Home':
                            iconName = 'home';
                            break;
                        case 'My Bid':
                            iconName = 'activity';
                            break;
                        case 'Cart':
                            iconName = 'shopping-cart';
                            break;
                        case 'Profile':
                            iconName = 'user';
                            break;
                        default:
                            break;
                    }
                    // return <Ionicons name={iconName} size={size} color={color} />;
                    // return <LottieView source={filePath} loop={false} autoPlay={focused} />;
                    return <Icon name={iconName} color={color} autoPlay={focused} size={25} />;
                },
                    tabBarStyle:{
                        borderTopEndRadius: 25,
                        borderTopStartRadius: 25,
                        //borderRadius:50,
                        height: 60,
                        color:'#5CDB95',
                    },
                    tabBarItemStyle:{
                      color:'#5CDB95',
                      margin: 10,
                      borderRadius:50,
                    },
                    tabBarInactiveTintColor: '#5D5C61',
                    tabBarActiveTintColor: '#5CDB95',
            })}
        >
            <Tabs.Screen name="Home" component={Home} />
            <Tabs.Screen name="My Bid" component={Mybid} />
            {/* <Tabs.Screen name="Cart" component={Cart} /> */}
            <Tabs.Screen name="Profile" component={MyProfile} />
        </Tabs.Navigator>
    );
}


export default Tab