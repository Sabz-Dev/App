import React, {useRef, useState} from 'react'
import {View, Text, StyleSheet, Image, Button, FlatList, Dimensions, TouchableOpacity} from 'react-native'

const {width, height} = Dimensions.get('window');
const carousalItems = [
    {text: 'Empowering Farmers', imgUrl: require('../../Sabzland/assets/slide-1.png')},
    {text: 'Easing Supply chain', imgUrl: require('../../Sabzland/assets/slide-2.png')},
    {text: 'Best Prices to Retailers', imgUrl: require('../../Sabzland/assets/slide-3.png')},
]
const viewConfigRef = {ViewAreaCoveragePercentThreshold: 95}


const CarousalItem = ({text, imgUrl,  navigation}) => {
    return(
        <View style={styles.carousalContainer}>
            <Text style={[styles.setFontSizeFour]}>{text}</Text>
            <Image style={styles.carousalImage} source={imgUrl}/>
            
        </View>
    )
}

const renderCarousalItem = ({item}) => {
    return(
        <CarousalItem text={item.text} imgUrl={item.imgUrl}/>
    )
}

const scrollToIndex = (index) => {
    flatlistRef.current?.scrollToIndex({animated: true, index: index})
}


const IntroductionScreen = ({navigation}) => {
    let flatlistRef = useRef()
    const [currentIndex, setCurrentIndex] = useState(0)
    const onViewRef = useRef(({changed}) => {
        if (changed[0].isViewable) {
            setCurrentIndex(changed[0].index)
        }
    })

    const skipIntro = () => {
        navigation.navigate('login')
    }
    const movetoapp = () => {
        navigation.navigate('tabs')
    }

    return(
        <View style={styles.container}>
            <FlatList 
                data={carousalItems}
                renderItem={renderCarousalItem}
                keyExtractor={(item, index) => index.toString()}
                style={styles.flatlistStyle}
                horizontal
                showsHorizontalScrollIndicator={false}
                pagingEnabled
                ref={(ref) => {flatlistRef.current = ref}} 
                //viewabilityConfig={viewConfigRef}
                 onViewableItemsChanged={onViewRef.current}
            />

            <View style={styles.dotView}>
                {carousalItems.map(({}, index) => (
                    <TouchableOpacity 
                        key={index.toString()} 
                        style={[styles.circle, {backgroundColor: index == currentIndex ? '#5CDB95' : '#4D6D9A'}]}
                        onPress={() => scrollToIndex(index)}
                    >
                    </TouchableOpacity>
                ))}
            </View>
            <View style={styles.skip}>
                <TouchableOpacity onPress={skipIntro}>
                    <Text style={styles.text}>Skip</Text>
                </TouchableOpacity>
            </View>
            <View>
                <TouchableOpacity onPress={movetoapp}>
                    <Text style={styles.text}>Home</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}

export default IntroductionScreen

const styles= StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FAFAFA',
        alignItems: 'center',
        justifyContent: 'center',
      },
      stretch: {
        width: 300,
        height: 300,
      },
      carousalContainer:{
        alignItems:'center',
      },
      carousalImage: {
        width,
        height: 250,
        resizeMode: 'cover',
        marginTop: 250,
      },
      flatlistStyle:{
        // maxHeight:300,
      },
      dotView : {
        flexDirection:'row',
        justifyContent:'center',
        marginVertical:20,
        position: 'absolute', left: 0, right: 0, bottom: 0,
        padding: 15, 
      },
      circle:{
        width: 10,
        height: 10,
        backgroundColor: '#4D6D9A',
         borderRadius:50,
         marginHorizontal: 10,
      },
      setFontSizeFour: {
        color: '#333333',
        marginTop: 50,
        fontSize: 25, // Define font size here in Pixels
        flex: 1,
        flexDirection:'row',
        position:'absolute',
        top:10,
        alignSelf: "center",
        justifyContent: "space-between",
        
      },
      skip:{
        position: 'absolute', right: 10, bottom: 0,
        flex: 1,
        color:'#5CDB95',
        paddingHorizontal: 15,
        paddingVertical: 28,
      },
      text:{
        color:'#5CDB95',
        fontSize: 18,
        },
})