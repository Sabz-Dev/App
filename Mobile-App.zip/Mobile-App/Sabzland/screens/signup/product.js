import React, {useRef, useState} from 'react'
import {View, Text, StyleSheet, Image, Button, ScrollView, FlatList, Dimensions, TouchableOpacity, TextInput, Linking} from 'react-native'
import Icon from 'react-native-vector-icons/FontAwesome';

const Product = ({navigation}) => {
        const [text, onChangeText] = React.useState(null);
        const [number, onChangeNumber] = React.useState(null);

        const movetolocation = () => {
            navigation.navigate('location')
          }

    return(
      <ScrollView contentContainerStyle={styles.ScrollView}>
        <View style={styles.container}>
            
            
            <View style={styles.inputbox}>
            <View style={styles.searchSection}>
              <TextInput
                style={styles.input}
                
                placeholder="Enter full name"
                keyboardType="default"
                value={text}
              />
              <Icon style={styles.searchIcon} name="user" size={20} color="#c5eae0"/>
              </View>

              <View style={styles.searchSection}>
              <TextInput
                style={styles.input}
                onChangeText={onChangeText}
                placeholder="Enter password"
                secureTextEntry={true}
                value={text}
              />
              <Icon style={styles.searchIcon} name="eye" size={20} color="#c5eae0"/>
              </View>

              <View style={styles.searchSection}>
              <TextInput
                style={styles.input}
                onChangeText={onChangeText}
                placeholder="Re-enter your password"
                secureTextEntry={true}
                value={text}
              />
              <Icon style={styles.searchIcon} name="eye-slash" size={20} color="#c5eae0"/>
              </View>
              
              <View style={styles.searchSection}>
              <TextInput
                style={styles.input}
                onChangeText={onChangeNumber}
                value={number}
                placeholder="Upload.."
                keyboardType="numeric"
                maxLength={6}
              />
              <Icon style={styles.searchIcon} name="link" size={20} color="#c5eae0"/>
              </View>
            </View>
            <View style={styles.buttonCallout}>
                <TouchableOpacity onPress={movetolocation}>
                <View style={styles.next}>
                    <Text style={{color:'#FAFAFA'}}>Next</Text>
                </View>
                </TouchableOpacity>
            </View>
            </View>
        </ScrollView>
    )
}

export default Product

const styles= StyleSheet.create({
  ScrollView:{
    flex: 1,
  },
    container: {
        flex:1,
        backgroundColor: '#FAFAFA',
        alignItems: 'center',
        justifyContent: 'center',
        
      },
      input: {
        margin: 10,
        height: 40,
        width: 225,
        padding: 10,
        borderColor: '#f0f9f6',
        borderWidth: 1,
        borderRadius: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#f0f9f6',
        
      },
      
      inputbox:{
        marginBottom: 30,
      },
      img:{
        aspectRatio: 3.5,
        //position: 'absolute', top: 100,
        resizeMode: 'contain'
      },
      text:{
        //position: 'absolute', top: 200,
        alignContent: 'center',
        marginTop: 30,
        marginBottom: 20,
        color:'#5CDB95',
        fontSize: 30,
        fontWeight: 'bold',
      },
      next:{
        borderColor: '#5CDB95',
        backgroundColor: '#5CDB95',
        borderStyle:'solid',
        borderWidth: 1,
        borderRadius: 5,
        paddingHorizontal: 120,
        paddingVertical: 15,
      },
      Ctext:{
        alignItems: 'center',
        alignContent: 'center',
        marginTop: 30,
        marginBottom: 30,
      },
      reset:{
        marginBottom: 30,
        
      },
      searchSection: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f0f9f6',
        marginBottom: 15,
        borderRadius: 5,
    },
    searchIcon: {
        padding: 10,
    },
    buttonCallout: {
        flex: 1,
        flexDirection:'row',
        position:'absolute',
        bottom:10,
        alignSelf: "center",
        justifyContent: "space-between",
        
      },

})