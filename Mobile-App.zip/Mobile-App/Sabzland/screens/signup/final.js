import React, {useRef, useState} from 'react'
import {View, Text, StyleSheet, Image, Button, ScrollView, FlatList, Dimensions, TouchableOpacity, TextInput, SafeAreaView} from 'react-native'
import Icon from 'react-native-vector-icons/FontAwesome';

const Verfication = ({navigation}) => {
        const [text, onChangeText] = React.useState(null);
        const [number, onChangeNumber] = React.useState(null);

        const movetoapp = () => {
          navigation.navigate('tabs')
        }
    return(
      <ScrollView contentContainerStyle={styles.ScrollView}>
        <View style={styles.container}>
          <View style={styles.congo}>
            <Icon name="check-circle" size={50} color="#5CDB95"/>
            <Text style={styles.Ctext}>Congratulations!</Text>
            <Text style={styles.text}>Your profile has been completed</Text>
          </View>
          <View style={styles.buttonCallout}>
              <TouchableOpacity onPress={movetoapp}>
              <View style={styles.next}>
                  <Text style={{color:'#FAFAFA'}}>Next</Text>
              </View>
              </TouchableOpacity>
            </View>

        </View>
        </ScrollView>
    )
}

export default Verfication

const styles= StyleSheet.create({
  ScrollView:{
    flex: 1,
  },
    container: {
        flex:1,
        backgroundColor: '#FAFAFA',
        
        
      },
      Ctext:{
        //position: 'absolute', top: 200,
        alignContent: 'center',
        marginTop: 25,
        marginBottom: 15,
        color:'#5CDB95',
        fontSize: 30,
        
      },
      next:{
        borderColor: '#5CDB95',
        backgroundColor: '#5CDB95',
        borderStyle:'solid',
        borderWidth: 1,
        borderRadius: 5,
        paddingHorizontal: 120,
        paddingVertical: 15,
      },
      text:{
        color: '#4D4D4D',
        alignItems: 'center',
        alignContent: 'center',
        fontSize: 15,
        fontWeight: 'bold',
      },
      reset:{
        marginBottom: 30,      
      },
      buttonCallout: {
        flex: 1,
        flexDirection:'row',
        position:'absolute',
        bottom:10,
        alignSelf: "center",
        justifyContent: "space-between",
        
      },
      congo:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 50,
      },
})