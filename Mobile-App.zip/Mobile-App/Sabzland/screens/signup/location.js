import * as React from "react"
import { Dimensions, StyleSheet, Text, View, TouchableOpacity } from "react-native"
import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete"
import MapView, { Callout, Circle, Marker } from "react-native-maps"

const Location = ({navigation}) => {
    const movetocnic = () => {
      navigation.navigate('cnic')
    }

  const [pin, setPin] = React.useState({
    latitude: 30.3753,
    longitude: 69.3451,
  })
  const [region, setregion] = React.useState({
    latitude: 30.3753,
    longitude: 69.3451,
  })
  return (
    <View style={{ flex:1}}>
      <GooglePlacesAutocomplete
        style={styles.loca}
        placeholder='Search'
        fetchDetails={true}
        GooglePlacesSearchQuery={{
				rankby: "distance"
				}}
        onPress={(data, details = null) => {
        // 'details' is provided when fetchDetails = true
        console.log(data, details);
      }}
      query={{
        key: "KEY",
        language: "en",
        components: "country:pk",
        types: "establishment",
        radius: 30000,
        location: `${region.latitude}, ${region.longitude}`
      }}
      styles={{
        container: { flex: 0, position: "absolute", width: "100%", zIndex: 1,
        margin: 50,
        height: 50,
        width: 275,
        padding: 10,
        borderColor: '#f0f9f6',
        borderWidth: 1,
        borderRadius: 5,
        backgroundColor: '#f0f9f6',  
      },
        listView: { backgroundColor: "white" }
      }}
    />

      <MapView
              region={{
                latitude: 30.3753,
                longitude: 69.3451,
                latitudeDelta: 3,
                longitudeDelta: 4,
              }}
              style={styles.map}
              showsUserLocation
              zoomEnabled={true}
              scrollEnabled={true}
              rotateEnabled={true}
              provider= "google"
            >
              <Marker
                  coordinate={{
                    latitude:30.3753,
                    longitude:69.3451}}
                    pinColor="black"
                    draggable={true}
                    onDragStart={(e) => {
                      console.log("Drag start", e.nativeEvent.coordinates)
                    }}
                    onDragEnd={(e) => {
                      setPin({
                        latitude: e.nativeEvent.coordinate.latitude,
                        longitude: e.nativeEvent.coordinate.longitude,
                      })
                    }}
                >
                  <Callout>
                      <Text>
                        I'm here
                      </Text>
                  </Callout>
              </Marker>
              <Circle center={pin}  radius={1000} />
            </MapView>


            <Callout style={styles.buttonCallout}>
            <TouchableOpacity onPress={movetocnic}>
              <View style={styles.next}>
                <Text style={{color:'#FAFAFA'}}>Next</Text>
              </View>
            </TouchableOpacity>
              
          </Callout>
            

    </View>
  );
}

export default Location

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
    alignItems: 'center',
    justifyContent: 'center',
  },
  map: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
  loca:{
    
  },
  next:{
    borderColor: '#5CDB95',
    backgroundColor: '#5CDB95',
    borderStyle:'solid',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 120,
    paddingVertical: 15,
  },
  buttonCallout: {
    flex: 1,
    flexDirection:'row',
    position:'absolute',
    bottom:10,
    alignSelf: "center",
    justifyContent: "space-between",
    
  },
  touchable: {
    backgroundColor: "lightblue",
    padding: 10,
    margin: 10
  },
  touchableText: {
    fontSize: 24
  },

});