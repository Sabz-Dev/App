//This is an example of online Emulator by https://aboutreact.com
import React, {useState, useMemo} from 'react';
import { Text, View, StyleSheet, Button, FlatList } from 'react-native';


// Item Component To render single items
function Item(props) {
  return (
    <View style={styles.item}>
      <Text>{props.item.id}: {props.item.Title} ({props.item.Status})</Text>
    </View>
  );
}

// Main App
const App = () => {
  // There are a lot of different ways to keep this info,
  // for the sake of this answer, I've put it in a useState hook
  const [fullList, setFullList] = useState([
    { "id":28, "Title":"Sweden", "Status":1 },
    { "id":56, "Title":"USA", "Status":1 },
    { "id":89, "Title":"England", "Status":1 },
    { "id":89, "Title":"England", "Status":2 },
    { "id":89, "Title":"England", "Status":2 },
    { "id":89, "Title":"England", "Status":3 } 
  ]);

  // Keep a statue of the current selected status
  const [status, setStatus] = useState('NONE')

  // the filtered list, cached with useMemo
  // the callback is call each time the status or the fullList changes
  const filteredList = useMemo(
    () => {
      if (status === 'NONE' ) return fullList
      return fullList.filter(item => status === item.Status)
    },
    [status, fullList]
  )

  // the onClick Method is a method that returns a method, which
  // updates the state based on the predefined status
  const onClick = (status) => () => {
      setStatus(status)
  }

  // render list using flat list, and the filter bar using standard buttons
  return (
    <View style={styles.container}>
      <Text>Selected Status: {status}</Text>
      <View style={styles.filterBar}>
        <Button title="Clear" onPress={onClick('NONE')} />
        <Button title="Status 1" onPress={onClick(1)} />
        <Button title="Status 2" onPress={onClick(2)} />
        <Button title="Status 3" onPress={onClick(3)} />
      </View>
      <FlatList
        style={styles.list}
        renderItem={Item}
        keyExtractor={(item) => item.id}
        data={filteredList}
      />
    </View>
  );
};

export default App;

// some basic styling
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 8,
    backgroundColor: 'white',
  },
  list: {
    height: '100%',
    width: '100%'
  },
  filterBar: {
      flexDirection: 'row',
      // flex: 0.2,
      height: 40,
  },
  item: {
    flex: 1,
    justifyContent: 'flex-start',
    padding: 8,
    backgroundColor: 'white',
  }
});