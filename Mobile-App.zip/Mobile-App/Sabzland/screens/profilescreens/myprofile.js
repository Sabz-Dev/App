import * as React from 'react';
import { FlatList, Text, View, StyleSheet, Button, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';

const Myprofile = ({navigation}) => {
  const countries = [
    {
      id: '1',
      name: 'Get Help',
      iconName: 'message-square',
    },
    {
      id: '2',
      name: 'Privacy Policy',
      iconName: 'file-text',
    },
    {
      id: '3',
      name: 'Terms & Condition',
      iconName: 'briefcase',
    },
    {
      id: '4',
      name: 'Call Us',
      iconName: 'phone-call',
      
    },
    {
      id: '5',
      name: 'Complaints',
      iconName: 'box',
    },
  ];
    return(
        <View style={styles.container}>

            <View style={styles.item}>
              <TouchableOpacity style={styles.profileicon}>
              <Icon name="user" color='#5CDB95' size={75} />
              </TouchableOpacity>
              
              <View style={styles.profilecontent}>
              <Text style = {{fontWeight: 'bold', fontSize: 15, color: '#5D5C61'}}>Bilal</Text>
              <Text style = {{fontWeight: 'bold', fontSize: 15, color: '#5D5C61'}}>Farmer</Text>
              <Text style = {{fontWeight: 'bold', fontSize: 15, color: '#5D5C61'}}>+923058553551</Text>
              </View>
              <TouchableOpacity>
              <Icon name="settings" color='#5CDB95' size={25} />
              </TouchableOpacity>

            </View>
          
          {/* <Text>Spash</Text>
          <Button
          title="Go to Details"
          onPress={() => navigation.navigate('intro')}
          /> */}
        
        
        <Text style = {{ fontWeight: 'bold', fontSize: 25, color: '#5D5C61', paddingLeft: 25, paddingBottom: 10 }}>About</Text>
        <FlatList 
          numColumns={1}
          data = {countries}
          renderItem = {({item}) => 
            <TouchableOpacity style={styles.about}>
              {/* <View style = {{backgroundColor: 'white', borderWidth: 1, borderColor: '#626262', height: 50, width: 50}}/> */}
              <Icon name={item.iconName} color={'#4D6D9A'} size={40} />
              <Text style = {{ fontSize: 18, color: '#5D5C61', paddingLeft: 25, paddingTop: 5 }}>{item.name}</Text>
              {/* <Text>{item.price}</Text> */}
            </TouchableOpacity>
            }
          />
          
        </View>
        
    )
}

export default Myprofile

const styles= StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FAFAFA',
      },

      item: {
        backgroundColor: '#f0f9f6',
        padding: 10,
        marginVertical: 8,
        marginHorizontal: 16,
        borderRadius: 8,
        shadowColor: 'black',
        shadowOffset: { width: 3, height: 3 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        display: 'flex',
        flexDirection: 'row',
        flexBasis: 150,
        paddingLeft: 5,
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 3,
        },
        shadowOpacity: 0.29,
        shadowRadius: 4.65,
        elevation: 7,
        
      },
      profileicon: {
        marginTop: 25,
        marginLeft: 25,
        marginRight: 25,
      },
      profilecontent: {
        margin: 25,
      },
      about: {
        backgroundColor: '#f0f9f6',
        padding: 10,
        marginVertical: 8,
        marginHorizontal: 16,
        borderRadius: 8,
        shadowColor: '#000',
        shadowOffset: { width: 3, height: 3 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        display: 'flex',
        flexDirection: 'row',
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 3,
        },
        shadowOpacity: 0.29,
        shadowRadius: 4.65,
        elevation: 5,
      },

})