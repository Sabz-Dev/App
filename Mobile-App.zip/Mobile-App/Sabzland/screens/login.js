import React, {useRef, useState} from 'react'
import {View, Text, StyleSheet, Image, Button, ScrollView, FlatList, Dimensions, TouchableOpacity, TextInput, SafeAreaView} from 'react-native'
//import SelectDropdown from 'react-native-select-dropdown'
import Icon from 'react-native-vector-icons/FontAwesome';

const LogIn = ({navigation}) => {
        const [text, onChangeText] = React.useState(null);
        const [number, onChangeNumber] = React.useState(null);

        const movetoverification = () => {
          navigation.navigate('verification')
        }

        const movetoprofile = () => {
          navigation.navigate('profile')
        }

        // const countries = ["Pakistan"]

        const CustomText = (props) => {
          const text = props.text.split(' ');
          return <Text>{text.map(text => {
            if (text.startsWith('S') || text.startsWith('U') || text.startsWith('-')) {
              return <Text style={{ color: '#5CDB95' }}>{text} </Text>;
            }
            return `${text} `;
          })}</Text>;
    }
    return(
      <ScrollView contentContainerStyle={styles.ScrollView}>
        <View style={styles.container}>
            
            <Image 
              style={styles.img}
              source={require('../../Sabzland/assets/Sabzlandtech-green.png')} 
            />

            <Text style={styles.text}>Log In</Text>
            
            <View style={styles.inputbox}>
            <View style={styles.searchSection}>
              <TextInput
                style={styles.input}
                mode="flat"
                onChangeText={onChangeText}
                placeholder="Select Country"
                value={text}
              />
              <Icon style={styles.searchIcon} name="chevron-down" size={20} color="#c5eae0"/>
              </View>
              <View style={styles.searchSection}>
              <TextInput
                style={styles.input}
                onChangeText={onChangeNumber}
                value={number}
                placeholder="Enter Phone Number"
                keyboardType="phone-pad"
                maxLength={11}
              />
              <Icon style={styles.searchIcon} name="phone" size={20} color="#c5eae0"/>
              </View>
            </View>
            <TouchableOpacity onPress={movetoverification}>
              <View style={styles.next}>
                <Text style={{color:'#FAFAFA'}}>Next</Text>
              </View>
            </TouchableOpacity>
            
            <View style={styles.Ctext}>
              <CustomText style={styles.Ctext} text="------------------------------ OR ------------------------------"/>
            </View>

            <TouchableOpacity onPress={movetoprofile}>
              <CustomText text="Don't have an account Sign Up"/>
            </TouchableOpacity>

            {/* <SelectDropdown
              style={styles.input}
              data={countries}
              onSelect={(selectedItem, index) => {
              console.log(selectedItem, index)
            }}
            >Select</SelectDropdown> */}

            

        </View>
        </ScrollView>
    )
}

export default LogIn

const styles= StyleSheet.create({
  ScrollView:{
    flex: 1,
  },
    container: {
        flex:1,
        backgroundColor: '#FAFAFA',
        alignItems: 'center',
        justifyContent: 'center',
        
      },
      input: {
        margin: 10,
        height: 40,
        width: 225,
        padding: 10,
        borderColor: '#f0f9f6',
        borderWidth: 1,
        borderRadius: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#f0f9f6',
        
      },
      inputbox:{
        marginBottom: 30,
      },
      img:{
        aspectRatio: 3.5,
        //position: 'absolute', top: 100,
        resizeMode: 'contain'
      },
      text:{
        //position: 'absolute', top: 200,
        alignContent: 'center',
        marginTop: 30,
        marginBottom: 20,
        color:'#5CDB95',
        fontSize: 30,
        fontWeight: 'bold',
      },
      next:{
        borderColor: '#5CDB95',
        backgroundColor: '#5CDB95',
        borderStyle:'solid',
        borderWidth: 1,
        borderRadius: 5,
        paddingHorizontal: 120,
        paddingVertical: 15,
      },
      Ctext:{
        alignItems: 'center',
        alignContent: 'center',
        marginTop: 30,
        marginBottom: 30,
      },
      selectdown:{
        margin: 10,
        height: 60,
        width: 275,
        padding: 10,
        borderColor: '#f0f9f6',
        borderWidth: 1,
        borderRadius: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#f0f9f6',
      },
      searchSection: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f0f9f6',
        marginBottom: 15,
        borderRadius: 5,
    },
    searchIcon: {
        padding: 10,
    },
})