import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

//screens
import IntroductionScreen from './screens/Introduction';
import SplashScreen from './screens/Splash';
import LogIn from './screens/login';
import Verfication from './screens/verification';
import Profile from './screens/signup/profile';
import Product from './screens/signup/product';
import Location from './screens/signup/location';
import CNIC from './screens/signup/cnic';
import Final from './screens/signup/final';
import Tabs from './screens/navigation/tabs';
import Home from './screens/homescreens/home';
import Bids from './screens/mybidscreens/bids';
  import AllBids from './screens/mybidscreens/allbids';
  import RelevantBids from './screens/mybidscreens/relevantbids';
  import BidDetails from './screens/mybidscreens/biddetail';
  import ApplyBid from './screens/mybidscreens/applybid';
  import FinalBid from './screens/mybidscreens/finalbid';
import Cart from './screens/cart';
import MyProfile from './screens/profilescreens/myprofile';

const Stack = createNativeStackNavigator()

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name='Intro' component={IntroductionScreen} />
        <Stack.Screen name='splash' component={SplashScreen} />
        <Stack.Screen name='login' component={LogIn} />
        <Stack.Screen name='verification' component={Verfication} />
        <Stack.Screen name='profile' component={Profile} />
        <Stack.Screen name='product' component={Product} />
        <Stack.Screen name='location' component={Location} />
        <Stack.Screen name='cnic' component={CNIC} />
        <Stack.Screen name='final' component={Final} />
        <Stack.Screen name='tabs' component={Tabs} />
        <Stack.Screen name='home' component={Home} />
        <Stack.Screen name='bids' component={Bids} />
          <Stack.Screen name='allbids' component={AllBids} />
          <Stack.Screen name='relevantbids' component={RelevantBids} />
          <Stack.Screen name='biddetail' component={BidDetails} />
          <Stack.Screen name='applybid' component={ApplyBid} />
          <Stack.Screen name='finalbid' component={FinalBid} />
        <Stack.Screen name='cart' component={Cart} />
        <Stack.Screen name='myprofile' component={MyProfile} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
